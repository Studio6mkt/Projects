<?php
if (isset($_COOKIE['auth'])) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualizar Mensagens</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
    </br>
        <h1 class="text-center">Mensagens Enviadas</h1>
        </br>
        <ul class="list-group">
            <?php
            $files = glob("../messages/*");
            foreach ($files as $file) {
                echo '<li class="list-group-item"><a href="/admin/read.php?file=' . urlencode($file) . '">' . basename($file) . '</a></li>';
            }
            ?>
        </ul>
    </div>
</body>
</html>
<?php
} else {
    header('Location: /admin/login.php');
}
?>