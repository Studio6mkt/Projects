<?php
$salt = "698dc19d48";
$users = [
    'roberto' => 'a720902858af0440838a6a47c8f6bb71',
    'marcela' => '2e7c3f01704b4f760eeed532c425ea95',
    'william' => '7c78c40edb5004f712fe55921f786a51',
    'amanda' => '2e7c3f01704b4f760eeed532c425ea95',
    'admin' => 'a720902858af0440838a6a47c8f6bb71'
];

if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (isset($users[$username]) && $users[$username] === md5("$password$salt")) {
        setcookie('auth', base64_encode($username . ':' . $password), time() + 3600);
        header('Location: index.php');
    } else {

        if(isset($users[$username])) {
            header("Location: login.php?error=1&account=$username");
        } else {
            header('Location: login.php?error=1');
        }
        
    }
} else {
    header('Location: login.php?error=1');
}
?>