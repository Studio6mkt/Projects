<?php
if (isset($_POST['name']) && isset($_POST['email']) && isset($_POST['subject'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];

    $filename = "messages/" . time() . ".txt";
    $content = "Nome: $name </br>E-mail: $email</br>Assunto: $subject</br>";

    if (file_put_contents($filename, $content)) {
        echo "OK";
    } else {
        echo "Ocorreu um erro ao salvar a mensagem.";
    }
} else {
    echo "Por favor, preencha todos os campos.";
}
?>