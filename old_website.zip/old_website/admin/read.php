<?php
if (isset($_COOKIE['auth'])) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ler Mensagem</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
    </br>
        <h1 class="text-center">Ler Mensagem</h1>
        <?php
        if (isset($_GET['file'])) {
            $file = urldecode($_GET['file']);
            $file_type = pathinfo($file, PATHINFO_EXTENSION);
            
            if (file_exists($file)) {
                
                $content = include($file);
                echo '<pre>' . htmlspecialchars($content) . '</pre>';

            } else {
                echo '<p class="alert alert-danger">O arquivo solicitado não foi encontrado.</p>';
            }
        } else {
            echo '<p class="alert alert-danger">Nenhum arquivo foi selecionado.</p>';
        }
        ?>
        <a href="/admin" class="btn btn-primary">Voltar</a>
    </div>
</body>
</html>
<?php
} else {
    header('Location: login.php');
}
?>