<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file-upload'])) {
    $target_dir = "../messages/";
    $target_file = $target_dir . time() . "_" . basename($_FILES["file-upload"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    if (file_exists($target_file)) {
        echo "O arquivo já existe.";
        $uploadOk = 0;
    }

    if ($_FILES["file-upload"]["size"] > 500000) {
        echo "O arquivo é muito grande.";
        $uploadOk = 0;
    }

    if ($imageFileType == "PHP") {
        echo "Extensão não permitida";
        $uploadOk = 0;
    }

    if ($uploadOk == 0) {
        echo "Seu arquivo não foi enviado.";
    } else {
        if (move_uploaded_file($_FILES["file-upload"]["tmp_name"], $target_file)) {
            echo "O arquivo foi enviado com sucesso.";
        } else {
            echo "Ocorreu um erro ao enviar seu arquivo.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload de Arquivo</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container">
</br>
        <h1 class="text-center">Upload de Arquivo</h1>
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="file-upload">Selecione um arquivo</label>
                <input type="file" class="form-control-file" id="file-upload" name="file-upload" disabled>
            </div>
            <button type="submit" class="btn btn-primary" disabled>Upload</button>
        </form>
    </div>
</body>
</html>
