<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
</br></br>
        <h1 class="text-center">Login</h1>
        <?php
        if (isset($_GET['error']) && !isset($_GET['account'])) {
            echo '<p class="alert alert-danger">Usuário ou senha inválidos.</p>';
        } elseif($_GET['account']) {
            $username = $_GET['account'];
            echo "<p class=\"alert alert-danger\">Senha inválida para usuário '$username'.</p>";
        }
        ?>
        <form action="authenticate.php" method="post">
            <div class="form-group">
                <label for="username">Usuário</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Senha</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary">Entrar</button>
        </form>
    </div>
</body>
</html>
